package com.example.todolist.data.util

class Constants {
    companion object{
        const val MAX_TIMESTAMP = 8640000000000000
        const val sDate = 1640908800 // no of seconds passed from 1970 to 2021
    }
}